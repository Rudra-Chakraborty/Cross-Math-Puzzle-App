package com.example.w2081487mobileapplicationcw1

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.modifier.modifierLocalProvider
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.w2081487mobileapplicationcw1.ui.theme.W2081487MobileApplicationCW1Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
                DisplayButtons()
        }
    }
}

@Composable
//this are the buttons that the user will see at first page task 1 and 2
fun DisplayButtons() {
    var openPopUpWindow by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current
    // I haved used rembersavable so that it rembers whrn
    //the oriantating is changed and untile the user clicks on i confirsm button it will not go back



    Column(
        modifier = Modifier.fillMaxSize().background(Color.Yellow),
        //i have arroaged the buttons at the center so it is user friendly
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally



    ) {
        Text(" Welcome to Math Cross Game ", fontSize = 26.sp,color = Color.Blue,fontWeight = FontWeight.Bold)
        Text(" Learn Math in the fun way ", fontSize = 24.sp,color = Color.Blue,fontWeight = FontWeight.Bold)
        Spacer(modifier= Modifier.height(100.dp))
        Button(onClick = {
            val intent = Intent(context, gameGUI::class.java)

            context.startActivity(intent)


        }) {
            Text("New Game", fontSize = 18.sp)
        }
        Button({

        }) {
            Text("Advanced Level", fontSize = 18.sp)
        }
        Button({
            openPopUpWindow = true
        }) {
            Text("About", fontSize = 18.sp)
        }

        if (openPopUpWindow) {
            AlertDialog(
                { openPopUpWindow = false },
                confirmButton = {
                    Button(onClick = { openPopUpWindow = false }) {
                                Text("I confirm")
                            }
                        },
                        text = {
                            Text(
                                " Student Id: w2081487 \n" +
                                        " Student Full Name : Rudra Chakraborty \n" +
                                        " I confirm that I understand what plagiarism is and have read and \n" +
                                        " understood the section on Assessment Offences in the Essential \n" +
                                        " Information for Students. The work that I have submitted is \n" +
                                        " entirely my own. Any work from other authors is duly referenced \n" +
                                        " and acknowledged."
                            )
                        }
                    )
                }
            }

    }



