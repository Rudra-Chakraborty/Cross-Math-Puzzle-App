package com.example.w2081487mobileapplicationcw1

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random
import com.example.w2081487mobileapplicationcw1.ui.theme.W2081487MobileApplicationCW1Theme

class gameGUI : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            CrossmathGUI()

        }
    }
}

@Composable
fun CrossmathGUI() {

    val context = LocalContext.current
    //i have used game Key  that be used to reset the game

    var gameKey by rememberSaveable {mutableStateOf(0)}
    // score variable is here becouse in task 5
    var score by rememberSaveable{mutableStateOf(0)}
    // timer states i have add because in task 10
    //it has ben montioned that timer toggle also should be add

    var timerEnabled by rememberSaveable{mutableStateOf(false) }
    //is 60 second which i have used time left
    var timeLeft by rememberSaveable{mutableStateOf(60) }
    //if the time store tha is game over
    var gameOver by rememberSaveable{mutableStateOf(false)}

    // random gred size of roes is redome from 11 min and max 20 as moontioned
    //game key is to resat so it changes the row and column when generated rendomly
    //is from task 6
    val rows = rememberSaveable (gameKey){(11..20).random()}
    val cols = rememberSaveable(gameKey) {(11..20).random()}

    // calculate cell size depends on screen
    //https://www.youtube.com/watch?v=HmXgVBys7BU
    // i have used the above video to undersatnd how to work with diffrent screen sizes
    //i have learned how to use Local configuration to
    //make sure that the app can work with diffrent screen size and the orientation
    // it is used for dynamic  change of size of height and width

    val screenWidth = LocalConfiguration.current.screenWidthDp.dp
    val screenHeight = LocalConfiguration.current.screenHeightDp.dp
    //i have used minOf() so thatgrid fits horizintally and vertically
    val cellSize = minOf((screenWidth - 16.dp) / cols, (screenHeight - 200.dp) / rows)

    // map for answeers
    // aswers:
    // int key  list of entries in the grid
    // each entry this are the index is=Pair<Int, List<Int>> is part of pair
    //   first=main value and ths is the answer
    //   second=list of associated values are the part of value is the equation that is
    //part of the answers and later i have used it to map it and check the position
    // i have learded this and got the idea from folowing sources:

   // https://www.youtube.com/watch?v=h8cxYOs6noo&t=326s
    //https://kotlinlang.org/api/core/kotlin-stdlib/kotlin.collections/mutable-map-of.html
    //https://kotlinlang.org/api/core/kotlin-stdlib/kotlin/-pair/
    //
    val answers=
        rememberSaveable(gameKey)
        {mutableMapOf<Int, MutableList<Pair<Int, List<Int>>>>()}

    // store cell colours is used if the colour changes
    //task 4 in the specifiection i have read it asked for this
    //https://developer.android.com/codelabs/jetpack-compose-state#10
    val cellColours = rememberSaveable(gameKey) {
        MutableList(rows * cols){ Color.Transparent}.toMutableStateList( )//commented on mutable list below
    }

    // here i create the grid
    var grid = rememberSaveable(gameKey) {
        val g = MutableList(rows * cols) { "" }//is string  version
        // "" is means empty cells

        val equationCount = (rows * cols / 12) // i have divide by 12 is to out of 12 cels i can see
        //roughly 1 equeation so it is resonable about of equations

        repeat(equationCount) {
            placeEquation(g, rows, cols, answers) // this is for placing equations
        }

        // fills empty cells with blocks i have did like about 65 percent of grid will be blocked
        for (i in g.indices) { // all like the index it iterates throogh
            if (g[i] == "") {// if there is empty cell it places rendomly
                g[i] = if (Random.nextFloat() < 0.65f) "#"
                       else "" // around 65% the grid change to have the block
            }
        }

        g.toMutableStateList()// i have used toMutableStateList becouse i have
        //leaned about of the UI using state list updates automatically insted of mutable list
        //https://developer.android.com/codelabs/jetpack-compose-state#10
    }

    // timer logic i have used the coutndown tutorial   for this task number 10
    LaunchedEffect(timerEnabled, gameKey) { // LauchedEffect is from tutorial one of the exrsise
        if (timerEnabled) {
            timeLeft = 60
            gameOver = false

            while (timeLeft > 0 && timerEnabled) {
                delay(1000) // is in milli it is 60 second
                timeLeft-- //it decrements after it start
            }

            if (timerEnabled) gameOver = true// the game will be not playeba game over message will be shown
        }
    }
    // User imput dia when the are aswering questions
    var showDialog by rememberSaveable { mutableStateOf(false) }
    var selectedIndex by rememberSaveable { mutableStateOf(-1) }//value -1 becouse array index strats from 0

    //learned state saver from : https://www.youtube.com/watch?v=o4qbOO2XLZU
    //google and https://developer.android.com/develop/ui/compose/state-saving
    var inputText by rememberSaveable(stateSaver =TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(""))
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(top = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        // top bar score and toggle for each corner player can see score on the roght corner
        //and toggle on the left
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {


            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Timer",fontSize = 25.sp, color = Color.Black)
                Switch( //this is the swich component
                    checked = timerEnabled,
                    onCheckedChange = { timerEnabled = it }
                )
            }
            Text("SCORE: $score",fontSize = 25.sp)
        }

        // it will display the time
        //if the toggled on then timer is visible
        //this is for task number 10 in the specits desplaying at right top
        if (timerEnabled) {
            Text("Time: $timeLeft",fontSize = 22.sp, color = Color.Blue)// time left

        }

        // game over text
        if (gameOver) {
            Text("GAME OVER", color = Color.Red, fontSize = 25.sp )// game over text it will shouw after time at 0
        }

        Spacer(modifier = Modifier.height(10.dp))

        // draw grid the part of code is from week 8 tutorial tic tac toe
        //i have learned how to show the grid with diffrent colour code for
        // equatins and blocked cells
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            for (r in 0 until rows) {// it creates rows of cells that is random untile that value
                Row {
                    for (c in 0 until cols) {// each row has rendom number of cell in column

                        val index =r * cols + c//the index
                        val cell= grid[index]// each cell

                        // sett colours
                        val bgColor = when {
                            cell== "#" -> Color.Black
                            cellColours [index] != Color.Transparent -> cellColours [index]
                            cell == "" -> Color.Black
                            else -> Color.White
                        }

                        Box(
                            modifier = Modifier
                                .size(cellSize)
                                .padding(1.dp)
                                .border(1.dp, Color.Black)
                                .background(bgColor)
                                .clickable {
                                    // allow click only if not game over task 10 says about clickable
                                    //when not game over
                                    if (!gameOver && (cell == "?" || cellColours[index] == Color.Red)) {
                                        selectedIndex = index
                                        inputText = TextFieldValue("")

                                                showDialog = true
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (cell != "#") {
                                Text(text = cell)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))


    }

    // input dialog
    if (showDialog &&selectedIndex != -1) {
        AlertDialog(
            onDismissRequest ={ showDialog = false},
            confirmButton ={
                Button(onClick ={
                    // i have used .toIntOrNull so that
                    //it wont crash if the user enters wring input
                    //if the input valid return the number if not doest retun anything
                    val userAnswer = inputText.text.toIntOrNull()

                    // if user enters a a number it will validate and change cours
                    //accordigly
                    if (userAnswer != null) {
                        //here it checks if answer are matching it stores it to eqlist
                        val eqList = answers[selectedIndex] ?: return@Button// this lebel exits only fron on click function

                        val correct = eqList.all { userAnswer == it.first}//it is correct with first value of the list

                        // always save answer even if wrong
                        grid[selectedIndex] = userAnswer.toString()

                        if (correct) {
                            for ((_, cells) in eqList) {
                                //change colour to green of the correct equation
                                for (i in cells) cellColours [i] = Color.Green
                            }
                            score++
                            //from tutorial 8 toast  if is correct
                            Toast.makeText(context, "Correct!", Toast.LENGTH_SHORT).show()
                        } else {
                            for ((_, cells) in eqList) {
                                //clour changes to red if is wrong all the equation
                                for (i in cells) cellColours [i] = Color.Red
                            }
                            Toast.makeText(context, "Wrong!", Toast.LENGTH_SHORT).show()
                        }
                    }

                    showDialog = false
                }) {
                    // user can click ok to check the answer
                    Text("OK")
                }
            },
            dismissButton= {
                Button(onClick = { showDialog = false }) {
                    // also user can decide not to enter anything so cancel
                    Text("Cancel")
                }
            },
            text= {
                Column {
                    //this is what user will is in the dialog to enter a number
                    Text("Enter number:")
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = inputText,
                        onValueChange = { inputText = it }
                    )
                }
            }
        )
    }
}

// answer mapping
fun addAnswer(
    //https://kotlinlang.org/api/core/kotlin-stdlib/kotlin.collections/mutable-map-of.html
    // int is question index which is the key and value is mutable lis of pairs and each
    //pair contains int which are correct answer
    //list int is selected cell
    answers:MutableMap<Int, MutableList<Pair<Int, List<Int>>>>,
    index:Int,
    correct:Int,
    cells:List<Int>
) {
    if (answers[index]== null) {//checks the answer
        answers[index]= mutableListOf()
    }
    answers[index]!!.add(Pair(correct, cells)) // i have used !! so is not null otherwise app could crash
}

// place one equation (horizontal or vertical)
fun placeEquation(
    grid: MutableList<String>, //the puzzle grid
    rows: Int,                 //number of rows in the grid
    cols: Int,                 //number of columns in the grid
    answers: MutableMap<Int, MutableList<Pair<Int, List<Int>>>> //stores correct answers andd positions
) {
    val ops = listOf("+", "-", "*", "/") //possible operators

    repeat(200) { //try up to 200 times to place a valid equation

        val horizontal = Random.nextBoolean() // randomly decide horizontal or vertical placement

        val a = (1..9).random() //first operand 1–9
        val b = (1..9).random() //second operand 1–9
        val operater = ops.random()//randomly pick an operator

        val result = when (operater) {
            "+" -> a + b//addition
            "-" -> a - b//subtraction
            "*" -> a * b//multiplication
            "/" -> if (b != 0 && a % b == 0) a / b //division only if clean division no divide by 0
            // no remainder mod is used %
            else  return@repeat              //otherwise skip this attempt
            else -> return@repeat //safety fallback is should never hit and should be valid
        }

        val values = listOf(a.toString(), operater, b.toString(), "=", result.toString()) // full equation as strings

        // collect all filled cells not empty and not blocked '#'
        val existingCells = grid.mapIndexedNotNull { i, v ->
            if (v != "" && v != "#")
                i else null
        }

        //75% chance to try placing equation overlapping existing letters
        val useOverlap = existingCells.isNotEmpty() && Random.nextFloat() < 0.75f

        // pick ancho cell either overlapping or anywhere
        val anchorIndex = if (useOverlap) existingCells.random()
        else (0 until rows * cols).random()

        val anchorRow=anchorIndex / cols //row of anchor cell
        val anchorCol = anchorIndex % cols //column of anchor cell

        val offset = (0..4).random() //random offset to shift equation start

        val startRow: Int
        val startCol: Int

        if (horizontal) {
            startRow=anchorRow
            startCol =anchorCol - offset //shift left to fit equation

            //ensure equation fiyts within horizontal bounds
            if (startCol < 0 || startCol + 4 >= cols) return@repeat
        } else {
            startCol= anchorCol
            startRow = anchorRow - offset // shift upward for vertical placement

            // ensure equation fits within vertical bounds
            if (startRow < 0 || startRow + 4 >= rows) return@repeat
        }

        //generat list of grid indices where equation will beplaced
        val cells =if (horizontal) {
            List(5) { startRow * cols + startCol + it } //horizontal indices
        } else {
            List(5) { (startRow + it) * cols + startCol } //vertical indices
        }

        //if overlap is required ensure at least one cell overlaps existing content
        if (useOverlap && cells.none { grid[it] != "" && grid[it] != "#" }) {
            return@repeat
        }

        //ensure no conflicting  like existing grid must match or be empty
        if (cells.any {
                grid[it] != "" && grid[it] != values[cells.indexOf(it)]
            }) return@repeat

        val missingIndex =listOf(0, 2, 4).random() // rendomly hide one of:a, b, or result

        //place equation into grid, replacing one part with "?"
        for (i in 0..4) {
            grid[cells[i]] = if (i == missingIndex) "?" else values[i]
        }

        val correct= when (missingIndex) {
            0 -> a       // this is for missing first number
            2 -> b       //for the second number
            4 -> result  // and fo the missing result
            else -> return
        }

        //store correct answer along with position and full equation context
        addAnswer(answers, cells[missingIndex], correct, cells)

        return //stop after like correctly placing one equation
    }

}
